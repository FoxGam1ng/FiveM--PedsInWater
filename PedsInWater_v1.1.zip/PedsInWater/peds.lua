-- peds.lua
-- Diese Datei enthält die Hilfsfunktion zur Überprüfung, ob ein Modell ein Tire ist.

function IsThisModelAnAnimal(modelHash)

   -- print("--> DEBUG: IsThisModelAnAnimal Funktion wurde Aufgerufen mit Hash: " .. tostring(modelHash)) -- Debug Zeile

    local animalHashes = {

        -- Standard GTA Tiere:

        GetHashKey("a_c_chop"),
        GetHashKey("a_c_poodle"),
        GetHashKey("a_c_cat_01"),
        GetHashKey("a_c_cow"),
        GetHashKey("a_c_deer"),
        GetHashKey("a_c_humpback"),
        GetHashKey("a_c_sharkhammer"),
        GetHashKey("a_c_sharktiger"),
        GetHashKey("a_c_boar"),
        GetHashKey("a_c_chickenhawk"),
        GetHashKey("a_c_chimp"),
        GetHashKey("a_c_pug"),
        GetHashKey("a_c_coyote"),
        GetHashKey("a_c_fish"),
        GetHashKey("a_c_hen"),
        GetHashKey("a_c_mtlion"),
        GetHashKey("a_c_pig"),
        GetHashKey("a_c_pigeon"),
        GetHashKey("a_c_rat"),
        GetHashKey("a_c_retriever"),
        GetHashKey("a_c_rhesus"),
        GetHashKey("a_c_rottweiler"),
        GetHashKey("a_c_seagull"),
        GetHashKey("a_c_shepherd"),
        GetHashKey("a_c_westy"),
        GetHashKey("a_c_husky"),
        GetHashKey("a_c_cormorant"),
        GetHashKey("a_c_crow"),
        GetHashKey("a_c_dolphin"),
        GetHashKey("a_c_killerwhale"),
        GetHashKey("a_c_rabbit_01"),
        GetHashKey("a_c_stingray"),

        -- Custom:


    }

    for _, hash in ipairs(animalHashes) do
        if modelHash == hash then
            return true
        end
    end
    return false
end
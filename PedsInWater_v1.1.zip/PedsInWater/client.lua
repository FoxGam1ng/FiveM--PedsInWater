    local lastInWaterTime = GetGameTimer()

Citizen.CreateThread(function()
    
   -- print("--> DEBUG: Citizen.CreateThread gestartet") -- Debug Zeile

    while true do
        Citizen.Wait(0) -- Sehr kurze Wartezeit für schnelle Reaktionen

        local playerPed = PlayerPedId()

        -- Überprüfen, ob der Spieler-Ped existiert und gültig ist
        if DoesEntityExist(playerPed) and GetEntityType(playerPed) == 1 then -- 1 ist der Typ für PED

           -- print("--> DEBUG: Spieler-Ped existiert und ist Typ 1.") -- Debug Zeile


            local pedCoords = GetEntityCoords(playerPed)
            -- Sicherstellen, dass die Koordinaten gültig sind, bevor GetWaterHeightNoIce aufgerufen wird
            if pedCoords then

               -- print("--> DEBUG: Ped-Koordinaten sind gültig.") -- debug Zeile


                local isAnimal = IsThisModelAnAnimal(GetEntityModel(playerPed))

                if isAnimal then
                    local foundWater, waterHeight = GetWaterHeight(pedCoords.x, pedCoords.y, pedCoords.z)

                   -- print("--> DEBUG: foundWater: " .. tostring(foundWater) .. ", waterHeight: " .. tostring(waterHeight)) -- Debug Zeile


                    if foundWater and pedCoords.z < waterHeight then

                       -- print("--> DEBUG: Spieler-Ped ist im Wasser.") -- Debug Zeile

                        lastInWaterTime = GetGameTimer()
                        -- Aktiviere die Immunität und Wasser-Flags
                        SetEntityAsMissionEntity(playerPed, true, false)
                        SetEntityCanBeDamaged(playerPed, true) -- Wichtig: Spieler-Peds sollten Schaden nehmen können, aber nicht ertrinken

                        SetPedConfigFlag(playerPed, 281, true) -- CFG_PED_FORCE_WATER_ENTRY
                        SetPedConfigFlag(playerPed, 46, true)  -- CFG_PED_CAN_SWIM
                        SetPedConfigFlag(playerPed, 202, true) -- CFG_PED_CAN_DIVE

                        local currentHealth = GetEntityHealth(playerPed)
                        SetEntityHealth(playerPed, GetEntityMaxHealth(playerPed))
                        SetPedDiesInWater(playerPed, false)
                        SetEntityInvincible(playerPed, true)
                        SetPedCanRagdoll(playerPed, false)


                        Citizen.Wait(100)

                    else -- Wenn der Spieler NICHT im Wasser ist

                       -- print("--> DEBUG: Spieler-Ped ist nicht im Wasser.") -- Debug Zeile

                        -- Deaktiviere die Immunität und Wasser-Flags wieder, wenn nicht im Wasser
                        if GetGameTimer() - lastInWaterTime > 5000 then

                           -- print("--> DEBUG: Tier-Ped ist aus dem Wasser gekommen.") -- debug Zeile

                            SetEntityAsMissionEntity(playerPed, false, false)
                            SetPedConfigFlag(playerPed, 281, false)
                            SetPedConfigFlag(playerPed, 46, false)
                            SetPedConfigFlag(playerPed, 202, false)
                            SetPedDiesInWater(playerPed, true)
                            SetEntityInvincible(playerPed, false) 
                            SetPedCanRagdoll(playerPed, true)
                        end
                    end
                else 
                    SetEntityAsMissionEntity(playerPed, false, false)
                    SetPedConfigFlag(playerPed, 281, false)
                    SetPedConfigFlag(playerPed, 46, false)
                    SetPedConfigFlag(playerPed, 202, false)
                    SetPedDiesInWater(playerPed, true)
                    SetEntityInvincible(playerPed, false) 
                    SetPedCanRagdoll(playerPed, true)
                end 
            end 
        end 
    end 
end)

-- print("--> DEBUG: Script-Ende erreicht.") -- Debug Zeile
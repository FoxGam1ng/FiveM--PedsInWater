fx_version 'cerulean'
game 'gta5'

author 'FoxGaming'
description 'Verhindert das Sterben von Tieren im Wasser'

client_scripts {
    'client.lua',
    'peds.lua'
}